
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('backup-statuses','a:1:{i:0;a:8:{s:2:\"id\";i:0;s:4:\"name\";s:7:\"Laravel\";s:4:\"disk\";s:5:\"local\";s:9:\"reachable\";b:1;s:7:\"healthy\";b:1;s:6:\"amount\";i:1;s:6:\"newest\";s:15:\"hace 12 minutos\";s:11:\"usedStorage\";s:8:\"15.23 KB\";}}',1744820278),('backups-local','a:1:{i:0;a:4:{s:4:\"disk\";s:5:\"local\";s:4:\"path\";s:39:\"Laravel/only-db-2025-04-16-10-27-05.zip\";s:4:\"date\";s:19:\"2025-04-16 16:05:18\";s:4:\"size\";s:8:\"15.23 KB\";}}',1744820278),('spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:87:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:12:\"view_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:16:\"view_any_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:14:\"create_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:14:\"update_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:15:\"restore_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:19:\"restore_any_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:17:\"replicate_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:15:\"reorder_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:14:\"delete_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:18:\"delete_any_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:20:\"force_delete_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:24:\"force_delete_any_company\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:13:\"view_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:17:\"view_any_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:15:\"create_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:15:\"update_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:16:\"restore_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:20:\"restore_any_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:18:\"replicate_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:16:\"reorder_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:15:\"delete_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:19:\"delete_any_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:21:\"force_delete_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:25:\"force_delete_any_customer\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"view_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:17:\"view_any_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:15:\"create_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:15:\"update_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:16:\"restore_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:29;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:20:\"restore_any_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:30;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:18:\"replicate_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:31;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:16:\"reorder_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:15:\"delete_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:33;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:19:\"delete_any_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:34;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:21:\"force_delete_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:25:\"force_delete_any_employee\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:13:\"view_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:37;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:17:\"view_any_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:38;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:15:\"create_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:39;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:15:\"update_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:40;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:16:\"restore_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:41;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:20:\"restore_any_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:42;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:18:\"replicate_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:43;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:16:\"reorder_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:44;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:15:\"delete_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:45;a:4:{s:1:\"a\";i:46;s:1:\"b\";s:19:\"delete_any_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:46;a:4:{s:1:\"a\";i:47;s:1:\"b\";s:21:\"force_delete_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:47;a:4:{s:1:\"a\";i:48;s:1:\"b\";s:25:\"force_delete_any_incident\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:48;a:4:{s:1:\"a\";i:49;s:1:\"b\";s:14:\"view_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:49;a:4:{s:1:\"a\";i:50;s:1:\"b\";s:18:\"view_any_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:50;a:4:{s:1:\"a\";i:51;s:1:\"b\";s:16:\"create_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:51;a:4:{s:1:\"a\";i:52;s:1:\"b\";s:16:\"update_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:52;a:4:{s:1:\"a\";i:53;s:1:\"b\";s:17:\"restore_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:53;a:4:{s:1:\"a\";i:54;s:1:\"b\";s:21:\"restore_any_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:54;a:4:{s:1:\"a\";i:55;s:1:\"b\";s:19:\"replicate_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:55;a:4:{s:1:\"a\";i:56;s:1:\"b\";s:17:\"reorder_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:56;a:4:{s:1:\"a\";i:57;s:1:\"b\";s:16:\"delete_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:57;a:4:{s:1:\"a\";i:58;s:1:\"b\";s:20:\"delete_any_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:58;a:4:{s:1:\"a\";i:59;s:1:\"b\";s:22:\"force_delete_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:59;a:4:{s:1:\"a\";i:60;s:1:\"b\";s:26:\"force_delete_any_quotation\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:60;a:4:{s:1:\"a\";i:61;s:1:\"b\";s:9:\"view_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:61;a:4:{s:1:\"a\";i:62;s:1:\"b\";s:13:\"view_any_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:62;a:4:{s:1:\"a\";i:63;s:1:\"b\";s:11:\"create_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:63;a:4:{s:1:\"a\";i:64;s:1:\"b\";s:11:\"update_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:64;a:4:{s:1:\"a\";i:65;s:1:\"b\";s:11:\"delete_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:65;a:4:{s:1:\"a\";i:66;s:1:\"b\";s:15:\"delete_any_role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:66;a:4:{s:1:\"a\";i:67;s:1:\"b\";s:9:\"view_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:67;a:4:{s:1:\"a\";i:68;s:1:\"b\";s:13:\"view_any_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:68;a:4:{s:1:\"a\";i:69;s:1:\"b\";s:11:\"create_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:69;a:4:{s:1:\"a\";i:70;s:1:\"b\";s:11:\"update_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:70;a:4:{s:1:\"a\";i:71;s:1:\"b\";s:12:\"restore_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:71;a:4:{s:1:\"a\";i:72;s:1:\"b\";s:16:\"restore_any_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:72;a:4:{s:1:\"a\";i:73;s:1:\"b\";s:14:\"replicate_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:73;a:4:{s:1:\"a\";i:74;s:1:\"b\";s:12:\"reorder_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:74;a:4:{s:1:\"a\";i:75;s:1:\"b\";s:11:\"delete_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:75;a:4:{s:1:\"a\";i:76;s:1:\"b\";s:15:\"delete_any_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:76;a:4:{s:1:\"a\";i:77;s:1:\"b\";s:17:\"force_delete_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:77;a:4:{s:1:\"a\";i:78;s:1:\"b\";s:21:\"force_delete_any_user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:78;a:4:{s:1:\"a\";i:79;s:1:\"b\";s:21:\"page_ManageAppearance\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:79;a:4:{s:1:\"a\";i:80;s:1:\"b\";s:19:\"page_ManageCurrency\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:80;a:4:{s:1:\"a\";i:81;s:1:\"b\";s:18:\"page_ManageGeneral\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:81;a:4:{s:1:\"a\";i:82;s:1:\"b\";s:23:\"page_ManageLocalization\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:82;a:4:{s:1:\"a\";i:83;s:1:\"b\";s:15:\"page_ManageMail\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:83;a:4:{s:1:\"a\";i:84;s:1:\"b\";s:17:\"page_ManageReport\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:84;a:4:{s:1:\"a\";i:85;s:1:\"b\";s:27:\"page_TranslationManagerPage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:85;a:4:{s:1:\"a\";i:86;s:1:\"b\";s:18:\"page_MyProfilePage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:86;a:4:{s:1:\"a\";i:87;s:1:\"b\";s:20:\"widget_StatsOverview\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:1:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:11:\"super_admin\";s:1:\"c\";s:3:\"web\";}}}',1744906667);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_number` bigint unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_document_number_unique` (`document_number`),
  UNIQUE KEY `companies_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Master Electronics Perú S.A.C',99999999,NULL,'955927839','Calle Los Pepitos S/N',NULL,NULL,NULL),(2,'SAPORITI DEL PERÚ SAC',20510698542,NULL,NULL,'CALLE CAMINO REAL Nª 1801 INT B 16 - PARQUE INDUSTRIAL, SAN PEDRITO - SURCO ',NULL,NULL,NULL),(3,'BRADE PARACAS SA',20384928537,NULL,NULL,'CALLE INDEPENDENCIA Nª 150 - URB SURQUILLO, MIRAFLORES - LIMA',NULL,NULL,NULL),(4,'J&A SEELGER PERU SAC ',20521431793,NULL,NULL,'AV. CIRCUNVALACION Nª 2526, SAN LUIS - LIMA  ',NULL,NULL,NULL),(5,'INVERSIONES BRADE SA',20303972821,NULL,NULL,'CALLE INDEPENDENCIA Nª 141 - URB SURQUILLO, MIRAFLORES - LIMA',NULL,NULL,NULL),(6,'DISTRIBUIDORA DE LIBROS HERALDOS NEGROS SAC',20545326877,NULL,NULL,'JR. CENTENARIO Nª 170, BARRANCO - LIMA',NULL,NULL,NULL),(7,'BANCO DE CREDITO DEL PERÚ SA',20100047218,NULL,NULL,'CALLE CENTENARIO Nª 156 - URB LAS LADERAS DE MELGAREJO, LA MOLINA - LIMA',NULL,NULL,NULL),(8,'PEREDA DISTRIBUIDORES SRL',20136961528,NULL,NULL,'AV. MARISCAL LA MAR Nª 318 (ALMACEN 1ª Y 2ª PISO) MIRAFLOES - LIMA',NULL,NULL,NULL),(9,'DML GROUP SAC',20548272964,NULL,NULL,'JR. GENERAL LA PUENTE Nª 142 - URB LA ORRANTIA DEL MAR, SAN ISIDRO - LIMA',NULL,NULL,NULL),(10,'HOTEL ADVISORS COMPANY SAC',20600372441,NULL,NULL,'CALLE TARATA Nª 269 DPTO 1105 - URB LEURO, MIRAFLORES LIMA',NULL,NULL,NULL),(11,'UNIVERSIDAD SEÑOR DE SIPAN SAC ',20479748102,NULL,NULL,'CARRETERA PIMENTEL KM5, CHICLAYO - LAMBAYEQUE ',NULL,NULL,NULL),(12,'CARNERO ASOCIADOS SC',20137457068,NULL,NULL,'AV. FRAY LUIS DE LEON Nª 515 INT. 401, SAN BORJA - LIMA',NULL,NULL,NULL),(13,'ENVIRONMENTAL WATER AND SERVICE SAC',20516462664,NULL,NULL,'AV. JOSÉ LARCO Nª 1116 INT G, MIRAFLORES - LIMA',NULL,NULL,NULL),(14,'SELLING CONSULTING GROUP SAC',20517855686,NULL,NULL,'AV. VICTOR MAURTUA Nª 140 DPTO 605, SAN ISIDRO - LIMA',NULL,NULL,NULL),(15,'BONDI SA',20511937176,NULL,NULL,'AV. LAS ARTES NORTE Nª 448, SAN BORJA - LIMA',NULL,NULL,NULL),(16,'LUX INTECH CENTER ',20602095356,NULL,NULL,'AV. BOLIVAR Nª 970 DPTO 202, PUEBLO LIBRE - LIMA',NULL,NULL,NULL),(17,'INMOBILIARIA WESTON S.A.C',20565765681,NULL,NULL,'AV.EL PARQUE NORTE  Nº 480 OFC.304 - SAN ISIDRO',NULL,NULL,NULL),(18,'MIDA FISH SRL',20202126678,NULL,NULL,'AV.LA PAZ  Nº 1640 MIRAFLORES ',NULL,NULL,NULL),(19,'SANTA AMELIA S.A',20101950558,NULL,NULL,'CALLE .INDEPENDENCIA Nº 452 MIRAFLORES',NULL,NULL,NULL),(20,'CHECHII GUILFO S.A.C',20545673917,NULL,NULL,'AV.LA MAR Nº 333 INT.207 LIMA MIRAFLORES',NULL,NULL,NULL),(21,'VEGA REAL S.A.C',20300007903,NULL,NULL,'AV.REPUBLICA DE PANAMA  Nº 4093 OF.201 SAN ISIDRO',NULL,NULL,NULL),(22,'NIPON AUTO S.A.C',20507270761,NULL,NULL,'AV.MINERALES  830  LIMA LIMA',NULL,NULL,NULL),(23,'PROYECTO SEIS  S.A ',20507562389,NULL,NULL,'AV.LAS ARTES Nº 456A LIMA SAN BORJA',NULL,NULL,NULL),(24,'ALTADIS  S.A',20516577448,NULL,NULL,'AV.LAS ARTES 456 LIMA SAN BORJA ',NULL,NULL,NULL),(25,'INMOBILIARIA BRONTE S A C',20544465865,NULL,NULL,'CALLE.MONTEGRANDE Nº  129  URB.CHACARILLA  SURCO -LIMA',NULL,NULL,NULL),(26,'INDUSTRIAS DEL PAPEL  S.A.C',20518010833,NULL,NULL,'Jr. Zorritos Nro. 687 URB.CHACRA COLORADA  BREÑA',NULL,NULL,NULL),(27,'ORKUNIA S.A.C',20543581993,NULL,NULL,'CALLE.RICARDO ANGULO Nº 859   PISO 3 SAN ISIDRO LIMA ',NULL,NULL,NULL),(28,'I-PEX PERU S.A.C ',20344069361,NULL,NULL,'AV.IQUITOS Nº 366  -LIMA -LA VICTORIA',NULL,NULL,NULL),(29,'ADESA CONTRATISTAS GENERALES S.A.C',20535731854,NULL,NULL,'CANAVAL MOREYRA Nº 230 -SAN ISIDRO - LIMA',NULL,NULL,NULL),(30,'DROGUERIA LIPHARMA S.A.C',20523672801,NULL,NULL,'CALLE .MIGUEL GRAU  MZ G LOTE 25 CALLAO',NULL,NULL,NULL),(31,'URVIA CORPORACION ANDINA DE URBANISTAS S.A.C',20521329832,NULL,NULL,'CALLE ENRIQUE PALACIOS Nº 291- DPTO 101 - MIRAFLORES',NULL,NULL,NULL),(32,'TRADECORP HR S.A.C',20600266111,NULL,NULL,'AV.DEL AIRE Nº 1557  INT. 3    SAN LUIS - LIMA',NULL,NULL,NULL),(33,'INMOBILIARIA SAN FRANCISCO DE ASIS S.A.C',20137026750,NULL,NULL,'AV.AVIACION Nº 2608 URB.SAN BORJA  LIMA SAN BORJA',NULL,NULL,NULL),(34,'INMOBILIARIA CATANIA S.A',20419617831,NULL,NULL,'CALLE .MONTEGRANDE Nº 129 URB.CHACARILLA DEL ESTANQUE - SURCO',NULL,NULL,NULL),(35,'PROCYON S.A',20199922760,NULL,NULL,'CALLE LOS TOPACIOS Nº 153 URB.CERROS DE CAMACHO -SURCO',NULL,NULL,NULL),(36,'CONSORCIO COECSA',20565278771,NULL,NULL,'AV.LAS AMERICAS Nº 1666 - LA VICTORIA  - LIMA',NULL,NULL,NULL),(37,'NN GUILLEN S.A ',20525755321,NULL,NULL,'AV.NASARIO GARCIA Nº 200 URB .MIRAFLORES - CASTILLA- PIURA ',NULL,NULL,NULL),(38,'ASISTENCIA TECNICA Y JURIDICA  CONSULTORES S.C',20538025918,NULL,NULL,'AV.PASEO DE LA REPUBLICA Nº 3565  INT.1101 LIMA SAN ISIDRO',NULL,NULL,NULL),(39,'COMERCIAL LAC EIRL',20458119130,NULL,NULL,'P.J. HERMANOS CARCAMO  Nº127  URB.LUIS GERMAN ASTETE - SAN MIGUEL',NULL,NULL,NULL),(40,'CLARKE MODET & CO. PERU S.A.C',20256396000,NULL,NULL,'AV.CONQUISTADORES Nº1136 INT.304  SAN ISIDRO LIMA',NULL,NULL,NULL),(41,'INSTITUTO PROLOG DE VILLA EL SALVADOR S.A.C',20518835271,NULL,NULL,'MZ I LOTE 8  GRUPO 12 SECTOR 3 VILLA EL SALVADOR - LIMA',NULL,NULL,NULL),(42,'CENTRO MATIC S,A,C',20524993059,NULL,NULL,'PJ.VICTOR ANDRES BELAUNDE Nº 345  LOS PRECURSORES SANTIAGO DE SURCO',NULL,NULL,NULL),(43,'SINESA S.A ',20451645782,NULL,NULL,'AV.LOS CONTRUCTORES Nº755 MZ L LOTE 49 URB.SANTA RAQUEL LA MOLINA',NULL,NULL,NULL),(44,'INVERSIONES Y NEGOCIOS A&R S.A.C',20509572501,NULL,NULL,'AV,SAENZ PEÑA Nº 284 INT.503 PROV.CONSTITUCIONAL DEL CALLAO -CALLAO',NULL,NULL,NULL),(45,'INMOBILIARIA ALQUIFE S.A.C',20521218097,NULL,NULL,'AUTOPISTA PANAMERICA SUR Nº 2001 KM 38 PUNTA HERMOSA  LIMA',NULL,NULL,NULL),(46,'SUPERCONCRETO DEL PERU S.A',20100151627,NULL,NULL,'AV.MANUEL OLGUIN Nº 477 LOS GRANADOS SANTIAGO DE SURCO',NULL,NULL,NULL),(47,'PANASONIC PERUANA S.A ',20100165849,NULL,NULL,'AV.ALFREDO MENDIOLA Nº 1600 INDEPENDENCIA -LIMA PERU',NULL,NULL,NULL),(48,'INDECOPI ',20133840533,NULL,NULL,'CALLE.LA PROSA 104- SAN BORJA  LIMA',NULL,NULL,NULL),(49,'EMAPE  S.A',20100063337,NULL,NULL,'AV.VIA EVITAMIENTO Nº 1700 - ATE -LIMA',NULL,NULL,NULL),(50,'TRANSPORTE Y SERVICIOS SANTA CRUZ  S.A',20101285449,NULL,NULL,'AV.NARANJAL Nº 299 Nº C INT.15 NARANJAL INDUSTRIAL - INDEPENDENCIA - LIMA',NULL,NULL,NULL),(51,'ROALSA CONTRATISTAS GENERALES SRL',20508846780,NULL,NULL,'AV.CANAVAL Y MOREYRA Nº 239   5TO PISO OFICINA  C  URB .LIMATANBO  SAN ISIDRO',NULL,NULL,NULL),(52,'CORPORACION MINERA CENTAURO S.A.C',20457362294,NULL,NULL,'AV.PEDRO MIOTA Nº 850 Z.I INDUSTRIAL SAN JUAN DE MIRAFLORES -LIMA',NULL,NULL,NULL),(53,'PURIFIL INTERNACIONAL SRL ',20505907982,NULL,NULL,'AV.AVIACION Nº 2572 INT.B PISO 2  SAN BORJA - LIMA',NULL,NULL,NULL),(54,'IMA OPINION & MERCADO S.A.C',20266369493,NULL,NULL,'AV.GUARDIA CIVIL Nº 295  INT  503 URB.SAN BORJA - LIMA',NULL,NULL,NULL),(55,'IC &  C S.A.C',20517273673,NULL,NULL,'JR. ALMIRANTE GUISSE Nº 1853  DPTO 9  LINCE - LIMA',NULL,NULL,NULL),(56,'SERING S.A.C',20252132466,NULL,NULL,'AV.AVIACION Nº 2505  PISO 4 INT C URB. SAN BORJA - LIMA',NULL,NULL,NULL),(57,'THIESEN DEL PERU S.A ',20342339426,NULL,NULL,'AV.MCAL OSCAR BENAVIDES Nº 250  URB.EL PINO  SAN LUIS  - LIMA',NULL,NULL,NULL),(58,'FRAPIO  S.A.C ',20600662997,NULL,NULL,'JR. CAMINO REAL NRO. 1801 Z.I. PARQUE INDUSTRIAL SAN PEDRITO I MZ A LT 03 LIMA - LIMA - SANTIAGO DE SURCO',NULL,NULL,NULL),(59,'MERCADO HUAMANTANGA INVERSIONES EIRL',20512143157,NULL,NULL,'MERCADO DE HUAMANTANGA  PUENTE PIEDRA',NULL,NULL,NULL),(60,'BAIZA CONSTRUCIONES S.A.C',20600447204,NULL,NULL,'',NULL,NULL,NULL),(61,'PC PLANET NORTE EMPRESA INDIVIDUAL DE RESPONSABILIDAD LIMITADA',20526290390,'glohtc@hotmail.com',NULL,NULL,'Gloria Palomino','2025-03-10 13:25:12','2025-03-10 13:25:22'),(62,'WATER & ENVIRONMENTAL SERVICES PERU S.A.C - WES PERU S.A.C',20565487931,'hidro@wes.com.pe','985544885','AV. RICARDO PALMA NRO. 836 INT. 302 URB. MIRAFLORES (URBANIZACION SAN ANTONIO) LIMA - LIMA - MIRAFLORES',NULL,'2025-03-10 21:56:01','2025-03-10 21:56:01'),(63,'REPOSITORIOS PERU',10406381639,'Rcmoncada@gmail.com',NULL,NULL,NULL,'2025-03-12 14:08:20','2025-03-12 14:39:58'),(64,'CONAFOVICER',20100816611,'martin.delama@conafovicer.com','963703164 ','Prolongacion Cangallo  No.670 La Victoria','Martin  De Lama Collazos','2025-03-14 13:20:41','2025-03-14 13:20:41'),(65,'HOSPITAL DE VENTANILLA',20550992940,'mbuitron@insm.gob.pe','996 061 099','AV. PEDRO BELTRAN C3 S/N VENTANILLA - CALLAO - PROVINCIA CONSTITUCIONAL DEL CALLAO','Ing. Mery Buitron Alvarado','2025-03-17 12:21:39','2025-03-17 12:21:39'),(66,'SISWORD SRLTDA',20334013881,'lmalvaceda@sisworld.com.pe','994835521','JR. LAS PALOMAS NRO. 260 Lima, Provincia: Lima, Distrito: Surquillo,','LEZLY  MALVACEDA','2025-03-19 11:08:28','2025-03-19 11:59:26'),(67,'UNIVERSIDAD CATOLICA SANTO TORIBIO DE MOGROVEJO',20395492129,'vzarpan@usat.edu.pe','908 852 219','Av. San Josemaría Escrivá 855, Chiclayo.','Victor Nicolás Zarpán Vásquez','2025-03-19 16:19:28','2025-03-19 16:19:28'),(68,'CORPORACION DARUCHI S.A.C.',20515314424,'compras@daruchi.com','939974129','Cal. Atahualpa Nro. 553 Miraflores','Armando Begazo','2025-03-25 21:35:17','2025-03-25 21:35:17'),(69,'SICA SUPPLY E.I.R.L',20508903686,'compras@solucionestecnologicas.net.pe','926342958','AV. VENEZUELA NRO. 5355 FND. PANDO LIMA - LIMA - SAN MIGUEL','Mike Miranda','2025-03-28 17:13:03','2025-03-28 17:13:03'),(70,'AMPHOS 21CONSULTING PERÚ S.A.C',20547422407,'luis.revilla@amphos21.com','(01) 5921275','JIRON .PASEO DEL BOSQUE No.500 Int 201 URB.CHACARRILLA DEL ESTANQUE','Ing.Luis Revilla','2025-04-10 18:53:40','2025-04-10 18:53:40'),(71,'JOMA COMPANY SRL',20604565350,'kj_01@hotmail.com','992555400','CAL. CALENDULAS NRO. 553 DPTO. 301 San Juan de Lurigancho, Lima, Lima','ING.KEVIN ALDAVE','2025-04-11 18:17:46','2025-04-11 18:17:46');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `document_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_number` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_document_number_unique` (`document_number`),
  UNIQUE KEY `customers_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'D.N.I',11291761,'Sra. Julieta Nieves','carolina.reyes@example.org','996530469','Av. Francisco Garrido # 3 Piso 3\nPuerto Luciana Macías, Puno','2025-03-10 13:22:44','2025-03-10 13:22:44'),(2,'D.N.I',65007723,'Camilo Emilio Olivo Rosado','carvajal.vicente@example.net','960851221','Cl. Matías Villalobos # 8 \nHernandes Baja, Trujillo','2025-03-10 13:22:44','2025-03-10 13:22:44'),(3,'D.N.I',56171052,'Abril Emilia Rojas Molina','tomas35@example.org','960196422','Jr. Ariadna Prieto # 6 Piso 37\nAtencio  Sur, Cajamarca','2025-03-10 13:22:44','2025-03-10 13:22:44'),(4,'R.U.C',74087880,'Lic. Juan David Paz Ybarra','facundo79@example.net','974624171','Jr. Bianca Moreno # 7002 Hab. 801\nDon Isabel Benavides, Tarapoto','2025-03-10 13:22:44','2025-03-10 13:22:44'),(5,'D.N.I',33053492,'Ing. Ana Girón Borrego','silvana03@example.com','954951079','Cl. Lorenzo Aparicio # 1 Piso 3\nOrellana Alta, Ica','2025-03-10 13:22:44','2025-03-10 13:22:44'),(6,'Carné de extranjeria',94274278,'Sra. Malena Montero Becerra','anapaula10@example.org','983091595','Urb. Adriana Bustos # 25047 \nSan Damián, Ica','2025-03-10 13:22:44','2025-03-10 13:22:44'),(7,'Carné de extranjeria',23569609,'Santino Juan David Gaytán Roldán','leonardo33@example.net','927394244','Cl. Violeta De La Torre # 3628 Dpto. 457\nDon Luis Tapia, Lambayeque','2025-03-10 13:22:44','2025-03-10 13:22:44'),(8,'Carné de extranjeria',41002938,'Julián Esteban Quiroz Merino','oliva85@example.net','957389864','Jr. Salomé Santacruz # 9561 Piso 2\nBorrego  Oeste, Cuzco','2025-03-10 13:22:44','2025-03-10 13:22:44'),(9,'D.N.I',26464341,'Lic. Abril Villaseñor','elizabeth95@example.com','929112863','Jr. Bautista Escalante # 1736 Dpto. 012\nDon Joaquín Piña, Huaraz','2025-03-10 13:22:44','2025-03-10 13:22:44'),(10,'Carné de extranjeria',95380591,'Lucía Olivia Fuentes Alfaro','amanda.enriquez@example.org','976302752','Urb. Juan Ordóñez # 8695 Piso 5\nLola  Sur, Jauja','2025-03-10 13:22:44','2025-03-10 13:22:44'),(11,'R.U.C',80118356,'Ing. Juan Diego Laureano Piña Hijo','aguilera.antonella@example.com','932234509','Urb. Nahuel Girón # 1 \nAna Alta, Cajamarca','2025-03-10 13:22:44','2025-03-10 13:22:44'),(12,'R.U.C',9106571,'Ornela Sofía Orellana Hernádez','miguel.benavides@example.net','980206557','Av. Hugo Roque # 20610 Piso 9\nGral. Manuela, Jauja','2025-03-10 13:22:44','2025-03-10 13:22:44'),(13,'D.N.I',90752394,'Mariana Espinal Hijo','amanda.soliz@example.com','919671952','Urb. Ivanna Montero # 2339 \nGral. Aarón, Madre de Dios','2025-03-10 13:22:44','2025-03-10 13:22:44'),(14,'Carné de extranjeria',68093934,'Dra. Miranda Ruelas Quintana','mia.borrego@example.com','939055418','Urb. Joshua Venegas # 652 \nDiego Alejandro  Oeste, Huaraz','2025-03-10 13:22:44','2025-03-10 13:22:44'),(15,'Carné de extranjeria',39757197,'Ing. Ian Rivero Rocha Hijo','wchavez@example.com','949899993','Jr. Adriana Molina # 987 Piso 64\nSan Antonia, Piura','2025-03-10 13:22:44','2025-03-10 13:22:44'),(16,'Carné de extranjeria',47461154,'Lic. Isaac Ureña Acuña Hijo','elizabeth.robles@example.org','918772989','Av. María Paula Villarreal # 7 Dpto. 874\nEmma  Oeste, Tacna','2025-03-10 13:22:44','2025-03-10 13:22:44'),(17,'R.U.C',52640014,'Leonardo Escobar Hijo','micaela.velasco@example.net','962201089','Urb. Christian Guerrero # 8316 Piso 47\nSan Victoria, Puno','2025-03-10 13:22:44','2025-03-10 13:22:44'),(18,'R.U.C',22342691,'Simón Emiliano Griego Grijalva','luna23@example.com','902972553','Jr. Jesús Guillen # 984 Dpto. 657\nDon Ariana, Madre de Dios','2025-03-10 13:22:44','2025-03-10 13:22:44'),(19,'R.U.C',74177458,'María Alejandra Navarrete Hijo','espino.bautista@example.com','923901951','Cl. Irene Mora # 47749 \nVargas Baja, Ica','2025-03-10 13:22:44','2025-03-10 13:22:44'),(20,'Carné de extranjeria',56747403,'Ana Sofía Bonilla Hijo','nahuel80@example.net','988123838','Jr. Bautista Reséndez # 3340 Dpto. 103\nBonilla Alta, Cajamarca','2025-03-10 13:22:44','2025-03-10 13:22:44');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `names` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paternal_surname` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maternal_surname` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int unsigned NOT NULL,
  `birth_date` date NOT NULL,
  `document_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_number` int unsigned NOT NULL,
  `gender` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_email_unique` (`email`),
  UNIQUE KEY `employees_document_number_unique` (`document_number`),
  KEY `employees_company_id_foreign` (`company_id`),
  CONSTRAINT `employees_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Fany','García','Farfán','fanygarcia@gmail.com',9999999,'1998-05-30','D.N.I',33546645,'Female','Jr. Emily Escobedo # 64355 \nBarrientos Norte, Moquegua',1,'2025-03-10 13:22:44','2025-03-10 13:22:44');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `incidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attention_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attention_date` date NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `priority` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incidents_company_id_foreign` (`company_id`),
  CONSTRAINT `incidents_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `incidents` WRITE;
/*!40000 ALTER TABLE `incidents` DISABLE KEYS */;
INSERT INTO `incidents` VALUES (1,'0001','Solicitud','2025-03-05',2,'Alto','Maria Perez .- Solicita atencion porque no puede acceder al control de asistencia ZKTECO  ,para solucionar se tuvo que asistir presencialmente ,porque  el mikrotik por temas de seguridad cambio la IP  fija  ,se configuro en el equipo de control de asistencia agregando la IP que estaba cambiada.\nQuednado solucionado el problema.','pending','2025-04-01 13:01:21','2025-04-01 13:01:21'),(2,'0002','Solicitud','2025-03-05',2,'Alto','Barbara Roncal.Solicita atencion para su computadora  porque no puede ingresar al AX,se le atendio remotamente ,para validarle el certificado.','pending','2025-04-01 13:04:51','2025-04-01 13:04:51'),(3,'003','Requerimiento','2025-03-03',2,'Alto','Se renovaron  las licencias  del antivirus corporativo  para 29 equipos ,desde la consola  virtual via remota .','pending','2025-04-01 13:10:07','2025-04-01 13:10:07'),(4,'0004','Solicitud','2025-03-04',2,'Alto','Guisela Rojas .Solicta instalcionde office 2021 Pro  se le atendio remotamente, se instalo y se configuro quedando operativo.','pending','2025-04-01 13:18:12','2025-04-01 13:18:12'),(5,'0005','Solicitud','2025-03-06',2,'Alto','Lisseth Portocarrero .-Solicita atencion porque no puede ingresar al AX,se le atendio remotamente para validarle el certificado .','pending','2025-04-01 13:24:21','2025-04-01 13:24:21'),(6,'0006','Solicitud','2025-03-07',2,'Alto','Maria Perez  mediante correo solicita solución URGENTE al problema que está presentando Regina, no creo que solo se trate de reiniciar un equipo.\nSe  atendio  presencialmente  en la filial  y se configuro  el sistema Ax ,validando el certificado  y actualizando el mismo , quedando resuelto el problema.','pending','2025-04-02 16:35:51','2025-04-02 16:35:51'),(7,'007','Solicitud','2025-04-07',2,'Alto','Incidente 1: Configuración de Ticketera Epson C3500 en Área de Producción\nIncidente 2: Configuración de OneDrive en una PC de Producción','pending','2025-04-07 15:56:53','2025-04-07 15:57:10');
/*!40000 ALTER TABLE `incidents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'App\\Models\\Incident',2,'620638a1-e418-4883-a58f-1bc74a3285e1','files','imagen (45)','01JQS8E3B3YCSQPNZ68VM3V4BF.png','image/png','public','public',120877,'[]','[]','[]','[]',1,'2025-04-01 13:04:52','2025-04-01 13:04:52'),(2,'App\\Models\\Incident',6,'b25db661-fdfb-421b-9292-8f091c34e4f5','files','Ticket 0006 Saporiti','01JQW6X5MHAE2SR51BJ40VCTM1.png','image/png','public','public',137568,'[]','[]','[]','[]',1,'2025-04-02 16:35:51','2025-04-02 16:35:51');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_companies_table',1),(2,'0001_01_01_000000_create_employees_table',1),(3,'0001_01_01_000000_create_users_table',1),(4,'0001_01_01_000001_create_cache_table',1),(5,'0001_01_01_000002_create_jobs_table',1),(6,'2022_12_14_083707_create_settings_table',1),(7,'2024_02_20_131300_create_currency_settings',1),(8,'2024_02_20_131300_create_general_settings',1),(9,'2024_02_21_153246_create_mail_settings',1),(10,'2024_07_16_224252_create_appearance_settings',1),(11,'2024_07_16_230816_create_localization_settings',1),(12,'2024_07_17_132605_create_report_settings',1),(13,'2025_02_05_124844_create_notifications_table',1),(14,'2025_02_10_103843_create_incidents_table',1),(15,'2025_02_15_081854_create_customers_table',1),(16,'2025_02_15_081916_create_quotations_table',1),(17,'2025_02_15_081917_create_quotation_item_table',1),(18,'2025_02_18_123717_create_permission_tables',1),(19,'2025_02_25_120821_create_media_table',1),(20,'2025_04_10_103453_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view_company','web','2025-03-10 13:22:52','2025-03-10 13:22:52'),(2,'view_any_company','web','2025-03-10 13:22:52','2025-03-10 13:22:52'),(3,'create_company','web','2025-03-10 13:22:52','2025-03-10 13:22:52'),(4,'update_company','web','2025-03-10 13:22:52','2025-03-10 13:22:52'),(5,'restore_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(6,'restore_any_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(7,'replicate_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(8,'reorder_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(9,'delete_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(10,'delete_any_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(11,'force_delete_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(12,'force_delete_any_company','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(13,'view_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(14,'view_any_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(15,'create_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(16,'update_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(17,'restore_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(18,'restore_any_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(19,'replicate_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(20,'reorder_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(21,'delete_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(22,'delete_any_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(23,'force_delete_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(24,'force_delete_any_customer','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(25,'view_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(26,'view_any_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(27,'create_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(28,'update_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(29,'restore_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(30,'restore_any_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(31,'replicate_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(32,'reorder_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(33,'delete_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(34,'delete_any_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(35,'force_delete_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(36,'force_delete_any_employee','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(37,'view_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(38,'view_any_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(39,'create_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(40,'update_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(41,'restore_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(42,'restore_any_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(43,'replicate_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(44,'reorder_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(45,'delete_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(46,'delete_any_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(47,'force_delete_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(48,'force_delete_any_incident','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(49,'view_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(50,'view_any_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(51,'create_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(52,'update_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(53,'restore_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(54,'restore_any_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(55,'replicate_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(56,'reorder_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(57,'delete_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(58,'delete_any_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(59,'force_delete_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(60,'force_delete_any_quotation','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(61,'view_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(62,'view_any_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(63,'create_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(64,'update_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(65,'delete_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(66,'delete_any_role','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(67,'view_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(68,'view_any_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(69,'create_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(70,'update_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(71,'restore_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(72,'restore_any_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(73,'replicate_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(74,'reorder_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(75,'delete_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(76,'delete_any_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(77,'force_delete_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(78,'force_delete_any_user','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(79,'page_ManageAppearance','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(80,'page_ManageCurrency','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(81,'page_ManageGeneral','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(82,'page_ManageLocalization','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(83,'page_ManageMail','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(84,'page_ManageReport','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(85,'page_TranslationManagerPage','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(86,'page_MyProfilePage','web','2025-03-10 13:22:53','2025-03-10 13:22:53'),(87,'widget_StatsOverview','web','2025-03-10 13:22:54','2025-03-10 13:22:54');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quotation_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_item` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int unsigned NOT NULL,
  `product` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_item_quotation_id_foreign` (`quotation_id`),
  CONSTRAINT `quotation_item_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quotation_item` WRITE;
/*!40000 ALTER TABLE `quotation_item` DISABLE KEYS */;
INSERT INTO `quotation_item` VALUES (1,1,15,'Canaletas de 32 x 12 mm2 Marca Dexon','unidad',1428,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(2,1,30,'cable de 6 mm2 color rojo N#90','mts',571,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(3,1,30,'cable de 6 mm2 color blanco N#90','mts',571,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(4,1,60,'cable de 4 mm2 color rojo N#90','mts',428,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(5,1,60,'cable de 4 mm2 color blanco N#90','mts',428,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(6,1,2,'Tablero adosable','unidad',21428,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(7,1,1,'Peine monofasico','unidad',3571,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(8,1,5,'ITH de 2x50 AMP','unidad',10000,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(9,1,1,'terminal','unidad',3571,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(10,1,1,'puertas ... pernos','unidad',4285,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(11,1,3,'ITH de 2x20 AMP','unidad',7142,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(12,1,3,'ITH de 2x28 AMP','unidad',7000,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(13,1,12,'Caja para tq...','caja',2142,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(14,1,12,'Tomacorriente para estabilizador','unidad',3571,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(15,1,60,'Cable de 2.5mm2 color verde amarillo','mts',285,'','','2025-03-10 13:50:32','2025-03-10 13:50:32'),(16,1,1,'Mano de obra x2 dias','unidad',170000,'','','2025-03-10 13:50:32','2025-03-10 14:15:46'),(17,1,1,'Viaticos x2 dias','unidad',70000,'','','2025-03-10 13:50:32','2025-03-10 14:15:46'),(18,2,1,'Mantenimiento preventivo y pintado de WLM  Marca SOLINST modelo 101 x 200 mts. ','01',27000,'','','2025-03-10 22:05:53','2025-03-10 22:05:53'),(19,3,1,'NVR 64CH 8SATA - 220V (2)','unidad',160000,'','','2025-03-11 16:22:05','2025-03-17 17:44:51'),(20,3,8,'DISCO DURO PURPLE PRO WD 12 TERAS','unidad',32400,'','','2025-03-11 16:22:05','2025-03-17 16:40:51'),(21,4,1,'HPE Proliant DL380 Gen11 Intel Xeon-G 5418Y','und',814143,'','','2025-03-12 14:22:17','2025-03-12 17:10:22'),(22,4,14,'HPE 32GB (1x32GB) Dual Rank x8 Smart Memory Kit','und',62696,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(23,4,2,'HPE 480GB SATA 6G Mixed  Use SFF SSD','und',54571,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(24,4,4,'HPE 1.92TB SATA 6G Mixed  Use SFF SSD','und',132714,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(25,4,2,'Broadcom BCM5/412 Ethernet 10Gb 2-port SFP','und',58071,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(26,4,4,'HPE BladeSystem Class 10gb Short Range SFP ','und',25340,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(27,4,2,'HPE 1000W Flex Slot Titanium Hot Plug Power Supply Kit','und',56390,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(28,4,1,'Servicio de instalacion','und',260000,'','','2025-03-12 14:22:17','2025-03-12 17:10:23'),(32,5,1,'DHI-NVR5864-EI - NVR 64 CANALES - 2U -  SOPORTA 8HDDS - WIZSENSE - PN INTERNAL  DHI-NVR5864-EI','unid',113764,'','','2025-03-12 16:31:08','2025-03-12 16:31:08'),(33,5,8,'DISCO DURO PURPLE PRO WD 12 TERAS','unid',36400,'','','2025-03-12 16:31:08','2025-03-12 16:31:08'),(37,4,1,'Licencia Red Hat Enterprise Linux Server','und',54800,'','','2025-03-12 17:22:36','2025-03-12 17:22:36'),(38,4,1,'Licencia SUSE Linux Enterprise Server','und',65845,'','','2025-03-12 17:22:36','2025-03-12 17:22:36'),(39,6,1,'BATERIA PARA LAPTOP MARCA. HP MODELO No.15cw1063wth (laptop de Shirley )','01',28500,'','','2025-03-12 17:35:45','2025-03-12 17:35:45'),(40,7,1,'Servicio de configuracion (discos, camara, NVR) , reseteo MANUAL de 52 camaras','und',150000,'','','2025-03-12 17:52:42','2025-03-12 17:52:42'),(42,6,1,'Soporte para Laptop   15.6\"','01',6500,'','','2025-03-12 18:03:04','2025-03-13 10:27:50'),(43,4,1,'Licencia Windows Server 2019 Datacenter','und',56000,'','','2025-03-13 09:47:55','2025-03-13 09:47:55'),(44,4,1,'Licencia VMWare vSphere Hypervisor ESXI 7.0 Perpetual License','und',6147,'','','2025-03-13 09:47:55','2025-03-13 09:47:55'),(45,8,1,'TAPA DE REGISTRO DE  DRYWALL de 60x60 PARA TECHO','1',29661,'','','2025-03-14 13:24:57','2025-03-14 13:24:57'),(46,3,1,'SERVICIO DE INSTALACION Y CONFIGURACION DE NVR ','Pack',48556,'','','2025-03-17 16:40:51','2025-03-17 17:44:51'),(47,9,1,'Laptop Lenovo V15 G4  AMN R5 75204 2.8GHZ  8GB DE RAM, 256GB SSD M2 15.6\"','1',38000,'Lenovo','Laptop','2025-03-17 17:15:49','2025-04-02 17:52:57'),(49,10,1,'Mantenimiento  preventivo y reemplazo de 48 baterias de 12VDC  5.0AH','1',62000,'APC','UPS SRT5KXLI','2025-03-19 11:21:22','2025-03-19 11:21:22'),(50,10,1,'Mantenimiento  preventivo y reemplazo de 6 baterias   de  12VDC 5.0AH     ','1',62000,'APC','UPS SRT2.2KXLI ','2025-03-19 11:21:22','2025-03-19 11:21:22'),(51,11,48,'BATERIA PARA UPS  DE 12VDC ,5AH ','unid',1100,'RITAR','BATERIA','2025-03-19 11:33:00','2025-03-19 11:33:00'),(52,11,6,'BATERIA PARA UPS  DE 12VDC ,5AH ','unid',1100,'RITAR','BATERIA','2025-03-19 11:33:00','2025-03-19 11:33:00'),(53,12,1,'Gabinete para servidor DE 42RU LT IMPORTADO GABINETE DE PISO DE 2.10MT. (42RU) 60CM X 80CM  LT KIT DE 04 EXTRACTORES DE AIRE CON VENTILADORES ','1',235142,'LT','GABINETE','2025-03-19 12:35:49','2025-03-19 12:35:49'),(54,12,1,'Nexxt - Tablero de conexiones - CAT 6 24 puertos ','1',27400,'NEXXT','PATCH PANEL','2025-03-19 12:35:49','2025-03-19 12:35:49'),(55,13,1,'DESINSTALACION DE CENTRAL TELEFONICA INSTALACION , CONFIGURACION   Y VALIDACION  DE   11 ANEXOS . DESINSTALACION  DE SWITCH DE 24 PUERTOS,ACCESPOINT  ARUBA  E INSTALACION DE UPS FORZA.','1',30000,'INTELBRAS','CENTRAL TELEONICA','2025-03-19 12:44:42','2025-03-19 12:46:46'),(56,14,2,'PDU G4 MI OU 309 32A 1P 12XC13 , 12XC39','unid',157647,' EATON','Eaton EMIB05','2025-03-19 16:28:11','2025-04-07 16:42:46'),(57,15,1,'APC Smart-UPS SRT 2200VA - UPS - CA 230 V','unid',132279,'APC','  SRT2200XLI','2025-03-19 19:04:51','2025-03-19 19:04:51'),(58,15,1,'APC Smart-UPS SMT1500IC - UPS - CA 220/230/240 V  TECNOLOGIA (LINEA INTERACTIVA)','unid',71400,'APC','SMT1500IC','2025-03-19 19:04:51','2025-03-19 19:04:51'),(59,16,1,'SERVICIO DE CONFIGURACION  DEL IP A TRAVS DEL NETWORK DEL PROPIO EQUIPO UPS ','unid',35000,'APC','BYPASS','2025-03-19 19:27:47','2025-03-19 19:41:26'),(60,17,1,'DESCONECTAR , DESARMAR EL GABINETE Y  LA RED ','unid',40000,'LT','GABINETE ','2025-03-24 18:33:44','2025-03-24 18:44:50'),(61,17,1,'Desmontaje de tacho y pared de drywal  Desmontaje de puerta contraplacada  Sacar enchape de piso  Limpieza de piso pulido  Masillado y pintado de paredes afectadas por el desmontaje del drywal Desmont','GLOBAL',175000,'MT1','VARIOS','2025-03-24 18:33:44','2025-03-24 18:33:44'),(62,18,1,'SERVICIO D EDESINSTALACION E INSTALACION Y CONFIGURACION DE  UPS DE 10KVA   Y CONFIGURACION DE TARJETA D ERED PARA MONITOREO DE ALERTAS','unid',85000,'ELISE ','SERVICIO','2025-03-25 21:44:08','2025-03-25 21:44:08'),(63,19,1,'REVISION,DIAGNOSTICO  Y REPRACION DE SONIDO DE LA S JARDINERAS  DE CAFETERIA TERRAZA','unid',40000,'GENERICA ','SERVICIO','2025-03-27 06:56:47','2025-03-27 06:56:47'),(64,20,4,'BATERIA  DE  12VDC  A 9AH','unid',6082,'RITAR','BATERIA ','2025-03-28 17:28:41','2025-03-28 17:28:41'),(65,20,1,'SERVICIO DE MANTENIMIENTO  APC  MODELO .SRT1500RMXLADE UPS DE 1.5KVA Y REEMPLAZO DE BATERIAS ','Pack',38000,'APC','SERVICIO','2025-03-28 17:28:41','2025-03-28 17:28:41'),(66,21,1,'SERVICIO DE INSTALACION DE CABLEADO  E INSTALACION DE TOMACORRIENTE PARA TRANSFORMADOR DE AISLAMIENTO  Y UOS DE 2KVA','unid',35000,'Serv.','SERVICIO','2025-03-28 18:51:43','2025-03-28 18:51:43'),(67,21,1,'LLAVE TERMIICA DE 20AH','unid',4000,'BTICINO','LLAVE TERMICA ','2025-03-28 18:51:43','2025-03-28 18:51:43'),(68,21,1,'Tomacorriente Doble P/T Modus 4 Terra','unid',3900,'BTICINO','TOMACORRIENTE ','2025-03-28 18:51:43','2025-03-28 18:51:43'),(69,21,9,'CABLE THW-90 PLUS 450/750V 14 AWG INDECO','metro',300,'INDECO','CABLE No.14  ','2025-03-28 18:51:43','2025-03-28 18:51:43'),(70,21,1,'CAJA ADOPSABLE PARA TOMACORRIENTE ','unid',500,'OPALUX','CAJA  ADOPSABLE','2025-03-28 18:51:43','2025-03-28 18:51:43'),(71,22,2,'HPE Proliant DL360 Gen 11 Intel  Xeon-54410Y 12 core (2.00GHZ 33MB )32GB (1x32GB PCS 4880 RDIMM 8 plug  2.5inch small Form  factor x1 Tri-mode basic carrier  MR 408 - no optical  800W  3 year warranty','unid',20069532,'HP','P51930-B21','2025-04-10 18:29:15','2025-04-10 18:29:15'),(72,22,1,'HPE 32 GB ( DUAL BANK X 8 DDR5 4800 CAS 40 39 39 EC8 REGISTRERED SMART  MEMORY KIT','unid',0,'HP','P43328-B21','2025-04-10 18:29:15','2025-04-10 18:29:15'),(73,22,8,'HPE 2.4TB SAS 12G MISSION CRITICAL 10K SFF(2.5IN ) BASIC CARRIER 3 UEAR W 512e ISL','unid',0,'HP','p43328-B21','2025-04-10 18:29:15','2025-04-10 18:29:15'),(74,22,4,'HPE 480GB SATA GG MIXED USE  SFF(2.5IN)BASIC CARRIER MULTI VENDOR  SSD','unid',0,'HP','HARD DISK','2025-04-10 18:29:15','2025-04-10 18:29:15'),(75,22,2,'HPE 800W FLEX SLOT PLATINIUM HOT  PLUG LOW HALOGEN POWER SUPPLY KIT','unid',0,'HP','FUENTE','2025-04-10 18:29:15','2025-04-10 18:29:15'),(76,22,2,'HPE3Y TC CRIT DL 360 GEN 11HW SVC','unid',0,'HP','LICENCIA','2025-04-10 18:29:15','2025-04-10 18:29:15'),(77,22,2,'INTEL XEON 54410 Y 2.0GHZ 12 CORE 150W PROSESSOR  FOR HPE ','unid',0,'HP','PROCESADOR','2025-04-10 18:29:15','2025-04-10 18:29:15'),(78,22,4,'HPE DL3XX/560 GEN11 1U HIGH PERFORMANCE  HEAT SINK KIT','unid',0,'HP','SVR','2025-04-10 18:29:16','2025-04-10 18:29:16'),(79,22,2,'HPE DL3XX/560 GEN 11 1U HIGH PERFORMANCE  HEAT SINK KIT','unid',0,'HP','SVR','2025-04-10 18:29:16','2025-04-10 18:29:16'),(80,22,1,'HPE ProLiant DL380 Gen11 12LFF NC Configure-to-order Server','unid',0,'HP ','P52533-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(81,22,1,'HPE ProLiant DL380 Gen11 12LFF NC Configure-to-order Server U.S. - English Localization','unid',0,'HP','P52533-B21  ABA','2025-04-10 18:29:16','2025-04-10 18:29:16'),(82,22,2,'Intel Xeon-Silver 4510 2.4GHz 12-core 150W Processor for HPE','unid',0,'HP','P67091-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(83,22,2,'Factory Integrated','unid',0,'HP','P67091-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(84,22,2,'HPE 32GB (1x32GB) Dual Rank x8 DDR5-5600 CAS-46-45-45 EC8 Registered Smart Memory Kit','unid',0,'HP','P64706-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(85,22,2,'Factory Integrated','unid',0,'HP','P64706-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(86,22,1,'HPE ProLiant DL380 Gen11 2SFF U.3 HDD Stacking Drive Cage Kit','unid',0,'HP','P48811-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(87,22,1,'Factory Integrated','unid',0,'HP','P48811-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(88,22,2,'HPE 960GB NVMe Gen4 Mainstream Performance Read Intensive SFF BC U.3 Static V2 Multi Vendor SSD','unid',0,'HP','P64842-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(89,22,2,'Factory Integrated','unid',0,'HP','P64842-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(90,22,4,'HPE 6TB SATA 6G Business Critical 7.2K LFF LP 1-year Warranty 512e Multi Vendor HDD','unid',0,'HP','861742-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(91,22,4,'Factory Integrated','unid',0,'HP','861742-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(92,22,1,'HPE MR416i-p Gen11 x16 Lanes 8GB Cache PCI SPDM Plug-in Storage Controller','unid',0,'HP','P47777-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(93,22,1,'Factory Integrated','unid',0,'HP','P47777-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(94,22,1,'Broadcom BCM5719 Ethernet 1Gb 4-port BASE-T Adapter for HPE','unid',0,'HP','P51178-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(95,22,1,'Factory Integrated','unid',0,'HP','P51178-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(96,22,1,'HPE 96W Smart Storage Lithium-ion Battery with 145mm Cable Kit','unid',0,'HP','P01366-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(97,22,1,'Factory Integrated','unid',0,'HP','P01366-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(98,22,1,'HPE ProLiant DL360 Gen11 Storage Controller Enablement Cable Kit','unid',0,'HP','P48918-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(99,22,1,'Factory Integrated','unid',0,'HP','P48918-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(100,22,1,'Broadcom BCM5719 Ethernet 1Gb 4-port BASE-T OCP3 Adapter for HPE','unid',0,'HP','P51181-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(101,22,1,'Factory Integrated','unid',0,'HP','P51181-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(102,22,2,'HPE 800W Flex Slot Platinum Hot Plug Low Halogen Power Supply Kit','unid',0,'HP','P38995-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(103,22,2,'Factory Integrated','unid',0,'HP','P38995-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(104,22,1,'HPE ProLiant DL360 Gen11 CPU1 to OCP2 x8 Enablement Kit','unid',0,'HP','P51911-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(105,22,1,'Factory Integrated','unid',0,'HP','P51911-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(106,22,1,'HPE ProLiant DL380 Gen11 LFF Front Tri-Mode Cable Kit','unid',0,'HP','P56995-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(107,22,1,'Factory Integrated','unid',0,'HP','P56995-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(108,22,1,'HPE ProLiant DL380/DL560 Gen11 2U High Performance Fan Kit','unid',0,'HP','P48820-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(109,22,1,'Factory Integrated','unid',0,'HP','P48820-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(110,22,1,'HPE CE Mark Removal FIO Enablement Kit','unid',0,'HP','P35876-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(111,22,2,'HPE ProLiant DL380 Gen11 Standard Heat Sink Kit','unid',0,'HP','P49145-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(112,22,2,'Factory Integrated','unid',0,'HP','P49145-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(113,22,1,'HPE ProLiant DL3XX Gen11 Easy Install Rail 3 Kit','unid',0,'HP','P52341-B21','2025-04-10 18:29:16','2025-04-10 18:29:16'),(114,22,1,'Factory Integrated','unid',0,'HP','P52341-B21  0D1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(115,22,1,'HPE iLO Advanced Electronic License with 3yr Support on iLO Licensed Features','unid',0,'HP','E6U64ABE','2025-04-10 18:29:16','2025-04-10 18:29:16'),(116,22,2,'Microsoft Windows Server 2022 16-core Standard Reseller Option Kit en/fr/es/xc SW','unid',0,'HP','P46171-DN1','2025-04-10 18:29:16','2025-04-10 18:29:16'),(117,22,1,'HPE 3Y Tech Care Critical Service','unid',0,'HP','HU4A3A3','2025-04-10 18:29:16','2025-04-10 18:29:16'),(118,22,2,'HPE Std-16C ROK/FIO Support','unid',0,'HP','HU4A3A3     ZT0','2025-04-10 18:29:16','2025-04-10 18:29:16'),(119,22,1,'HPE DL380 Gen11 Support','unid',0,'HP','HU4A3A300DK','2025-04-10 18:29:16','2025-04-10 18:29:16'),(120,23,1,'MANTENIMIENTO GENERAL PARA GENERADOR  HYUNDAI  DE 6.5 KW','unid',42000,'HYUNDAI','MANTEMINIENTO','2025-04-10 18:57:45','2025-04-10 18:57:45'),(121,24,1,'SERVICIO DE MANTENIMIENTO DE LA  MAIMBOARD PORQUE SE ENCUENTRA  CON OXIDO YREPARACION DE FUENTE DE ALIMENTACION Y LA ETAPA DE POTENCIA DEL AMPLIFICADORY REFORZAMIENTO CON RESPUESTOS DE MEJOR CALIDAD .','unid',90000,'PERFECTION ','AMPLIFICADOR ','2025-04-11 18:37:28','2025-04-11 18:49:46'),(122,25,1,'Digitalizacion de planos, disiplinas de arquitectura y electricas. (modelo revit). Incluye 02 juegos de planos fisico y 01 digital.','Gbl.',380000,'Tda Guess','SERVICIO ','2025-04-12 16:51:56','2025-04-12 16:51:56'),(123,25,1,'Megado de cables y tableros electricos, protocolos de pruebas.','Gbl.',180000,'Tda Guess','SERVICIO','2025-04-12 16:51:56','2025-04-12 16:51:56'),(124,25,1,'Cuadro de cargas y MMDD Electrico, firmado por profesional habilitado.','Gbl.',150000,'Tda Guess','SERVICIO','2025-04-12 16:51:56','2025-04-12 16:51:56'),(125,25,1,' MMDD Civil, firmado por profesional habilitado.','Gbl.',150000,'Tda Guess','SERVICIO','2025-04-12 16:51:56','2025-04-12 16:51:56');
/*!40000 ALTER TABLE `quotation_item` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `requester_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` bigint unsigned NOT NULL,
  `payment_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `extra_conditions` json NOT NULL,
  `company_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotations_number_unique` (`number`),
  KEY `quotations_company_id_foreign` (`company_id`),
  CONSTRAINT `quotations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` VALUES (1,'','',1,'EFECTIVO','PEN',NULL,'null',61,'2025-03-10 13:50:32','2025-03-10 13:50:32'),(2,'','',2,'TRANSFERENCIA','PEN',NULL,'null',62,'2025-03-10 22:05:53','2025-03-10 22:05:53'),(3,'Eric Crisostomo ','',3,'EFECTIVO','USD','Este servicio no incluye mantenimiento de camaras  ,si hubiera  algunas camaras que no se pueda agregar al NVR ya sea porque no funcionen o se tenga que revisar manualmente tampoco, se enviara un informe detallado para que  evaluen el costo adicional.','null',5,'2025-03-11 16:22:05','2025-03-17 16:40:51'),(4,'Roberto Carlos Moncada','',4,'EFECTIVO','USD',NULL,'null',63,'2025-03-12 14:22:17','2025-03-13 10:09:10'),(5,'','',5,'EFECTIVO','USD',NULL,'null',5,'2025-03-12 16:31:08','2025-03-12 16:31:08'),(6,'Shirley caro','',6,'CREDITO','PEN','Se envia este presupuesto a solicitud de la  usuaria  Srta.Shirley Caro','null',58,'2025-03-12 17:35:45','2025-03-13 10:27:50'),(7,'','',7,'EFECTIVO','USD',NULL,'null',5,'2025-03-12 17:52:42','2025-03-12 17:52:42'),(8,'Martin De Lama','',8,'EFECTIVO','PEN','PRODUCTO ENTREGADO EN LA  OFICINA DE LA VICTORIA ','null',64,'2025-03-14 13:24:57','2025-03-14 13:24:57'),(9,'Rocio Diaz ','p1',9,'TRANSFERENCIA','USD',NULL,'[{\"name\": \"Tiempo de Entrega\", \"value\": \"2 días despues de la girada la orden de compra y abono.\"}]',58,'2025-03-17 17:15:49','2025-04-02 17:52:57'),(10,'Srta.Lezly Malvaceda','Mantenimiento de  Ups APC   de 5KVA  Y 2KVA',10,'TRANSFERENCIA','PEN','UPS SRT2.2KXLI  . Hay  que considerar que se va a reemplazar las baterias pero eso no nos garantiza  que el equipo quede operativo  sin alarmas ,por lo que hay realizar una revision mas detallada.','null',66,'2025-03-19 11:21:22','2025-03-19 11:21:22'),(11,'Srta.Lezly Malvaceda','BATERIAS  DE 12VDC ,5AH',11,'TRANSFERENCIA','USD',NULL,'null',66,'2025-03-19 11:33:00','2025-03-19 11:33:00'),(12,'Srta.Maria Perez','Gabinete  de comunicaciones de 42 RU',12,'TRANSFERENCIA','PEN','El gabinete se encuentra implementado con puntos de red  , puntos de voz punto de corriente  directo del tablero principal  esta indepndisado ,  listo para conectar  los Switch,servidor ...etc.','null',2,'2025-03-19 12:35:49','2025-03-19 12:35:49'),(13,'Srta.Maria Perez','Traslado de central telefonica analogica  del B21  al B16',13,'TRANSFERENCIA','PEN',NULL,'null',2,'2025-03-19 12:44:42','2025-03-19 12:44:42'),(14,'Victor Nicolás Zarpán Vásquez','PRESUPUESTO DE PDU  EATON EMIB05',14,'TRANSFERENCIA','USD','Pedido a  21 semanas  ,pago 100% adelantado','[{\"name\": \"sdf\", \"value\": \"sdf\"}]',67,'2025-03-19 16:28:11','2025-03-24 12:49:28'),(15,'Srta.Lezly Malvaceda','PRESUPUESTO DE UPS  APC DE 1KVA Y 2.2 KVA',15,'TRANSFERENCIA','USD',NULL,'null',66,'2025-03-19 19:04:51','2025-03-19 19:04:51'),(16,'Srta.Lezly Malvaceda','CONFIGURACION DE BYPASS APC ',16,'TRANSFERENCIA','PEN',NULL,'null',66,'2025-03-19 19:27:47','2025-03-19 19:27:47'),(17,'Srta.Maria Perez','DESMONTAJE DE GABINETE,CUARTO DE COMUNICACIONES ,CONDUIT Y OTROS',17,'TRANSFERENCIA','PEN','Forma de pago 60% de adelanto y saldo contra entrega ','[{\"name\": \"Tiempo de Entrega:2 días calendario\", \"value\": \" Despues de la girada la orden de compra y abono\"}]',2,'2025-03-24 18:33:44','2025-03-24 18:33:44'),(18,'Sr.Armando Begazo','PRESUPUESTO DE REEMPLAZO DE UPS DE 10KVA ',18,'TRANSFERENCIA','PEN','Solo se configurara la tarjeta de red para monitoreo de alertas .,mas no para monitoreo de servidores.','[{\"name\": \"Tiempo de Entrega:\", \"value\": \"1 Dia  despues de la girada la orden de compra y abono\"}]',68,'2025-03-25 21:44:08','2025-03-25 21:44:08'),(19,'Ing.Wilian  Tesen','SERVICIO DE REPARACION DE SONIDO PARA PARLANTES DE  JARDINERAS  TERRAZA',19,'CREDITO','PEN','Se realizara mantenimiento a los parlantes de las jardineras,reparacionde la linea  de audio es necesario que se reemplaze  esa consola  Peavey porque no esta funcionando correctamente.','[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra\"}]',5,'2025-03-27 06:56:47','2025-03-27 06:56:47'),(20,'Mike Miranda','PRESUPUESTO DE BATERIAS Y SERVICIO  D EMANTENIMIENTO',20,'TRANSFERENCIA','PEN',NULL,'[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra y abono\"}]',69,'2025-03-28 17:28:41','2025-03-28 17:28:41'),(21,'Sr.Armando Begazo','Servicio de instalacion tomacoriente  para uPS y tranformador  de 2KVA ',21,'TRANSFERENCIA','PEN',NULL,'[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra y abono\"}]',68,'2025-03-28 18:51:43','2025-03-28 18:51:43'),(22,'ING. MERY BUITRON','PRESUPUESTO DE  SERVIDORES HPE',22,'TRANSFERENCIA','PEN',NULL,'[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra\"}]',65,'2025-04-10 18:29:15','2025-04-10 18:29:15'),(23,'Ing. Luis Revilla','PRESUPUESTO DE MANTENIMIENTO PARA GENERADOR HYUNDAI',23,'TRANSFERENCIA','PEN',NULL,'[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra\"}]',70,'2025-04-10 18:57:45','2025-04-10 18:57:45'),(24,'KEVIN ALDAVE','PRESUPUESTO  DE REPARACION DE AMPLIFICADOR  DE TIENDA GUESS MEGAPLAZA',24,'TRANSFERENCIA','PEN','SE RECOGIO EL AMPLIFICADOR  PERFECTION MODELO .MIXER POWER  DP-200A,  Y SE REVISO ENCONTRANDOSE CON DEMASIADO POLVO  Y OXIDO ,POR LO QUE SE TIENE QUE HACER UN MANTENIMIENTO Y LAVADO AL ACIDO PARA PODER REPARARLO.','[{\"name\": \"Tiempo de Entrega:\", \"value\": \"2 días despues de la girada la orden de compra\"}]',71,'2025-04-11 18:37:28','2025-04-11 18:37:28'),(25,'KEVIN ALDAVE','PRESUPUESTO PARA MEMORIA DESCRIPTIVA Y CALCULOS TIENDA GUESS JOCKEY',25,'TRANSFERENCIA','PEN','1.- Se requiere 3 dias para levantamiento en la tienda.\n2.- Los elementos que no pasen las prueba de inspección y megado se reportaran para su corrección.\n3.- No incluye  adicionales .','[{\"name\": \"Tiempo de Entrega:\", \"value\": \"20 días despues de la girada la orden de compra y abono\"}]',71,'2025-04-12 16:51:56','2025-04-12 16:51:56');
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(81,1),(82,1),(83,1),(84,1),(85,1),(86,1),(87,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','web','2025-03-10 13:22:44','2025-03-10 13:22:44');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('4bWAvYq7DeCSj77qAShvxUsesdR48iRUX5XhDLnW',1,'181.224.238.242','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiek1wSEpRbjl3Y0Y2Z2h1U0Q3d2lZNWg5aWJES0IyMHBXVTNhVklMbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vbWFzdGVyZWxlY3Ryb25pY3MuZHVja2Rucy5vcmcvYWRtaW4vcXVvdGF0aW9ucy8xMi9lZGl0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRvNlBWRGdtekhYbWEwUFdVaVA3TGdlaUMyYVB3cVhpTXdmLkZvbzNQdjBRSzJYbHBtdzRSSyI7fQ==',1744818615),('GF5Gd4YVL9byldVt0MwlO4RD7QD2KIRCfX3NJlVE',1,'172.21.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo3OntzOjY6Il90b2tlbiI7czo0MDoiTlpCZXlkVUVaMjBXbFhZOVFiUUJqUU1zaVFUT1ZQRjl2elRST2lNeCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0NjoiaHR0cDovL2xvY2FsaG9zdDo4MDAxL2FkbWluL3F1b3RhdGlvbnMvMjUvZWRpdCI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM1OiJodHRwOi8vbG9jYWxob3N0OjgwMDEvYWRtaW4vYmFja3VwcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRvNlBWRGdtekhYbWEwUFdVaVA3TGdlaUMyYVB3cVhpTXdmLkZvbzNQdjBRSzJYbHBtdzRSSyI7czo4OiJmaWxhbWVudCI7YToxOntzOjEzOiJub3RpZmljYXRpb25zIjthOjE6e2k6MDthOjExOntzOjI6ImlkIjtzOjM2OiI5ZWIwYzM1MC04NjExLTRiMTUtYjJjMi1jMGQ3ZTI4NTFiNmYiO3M6NzoiYWN0aW9ucyI7YTowOnt9czo0OiJib2R5IjtOO3M6NToiY29sb3IiO047czo4OiJkdXJhdGlvbiI7aToyMjAwO3M6NDoiaWNvbiI7czoyMzoiaGVyb2ljb24tby1jaGVjay1jaXJjbGUiO3M6OToiaWNvbkNvbG9yIjtzOjc6InN1Y2Nlc3MiO3M6Njoic3RhdHVzIjtzOjc6InN1Y2Nlc3MiO3M6NToidGl0bGUiO3M6NDM6IkNyZWFuZG8gdW4gbnVldm8gcmVzcGFsZG8gZW4gc2VndW5kbyBwbGFuby4iO3M6NDoidmlldyI7czozNjoiZmlsYW1lbnQtbm90aWZpY2F0aW9uczo6bm90aWZpY2F0aW9uIjtzOjg6InZpZXdEYXRhIjthOjA6e319fX19',1744820282);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `payload` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_group_name_unique` (`group`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'currency','name',0,'\"Sol Peruano\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(2,'currency','code',0,'\"PEN\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(3,'currency','precision',0,'2','2025-04-16 11:17:24','2025-04-16 11:17:24'),(4,'currency','symbol',0,'\"S/.\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(5,'currency','symbol_first',0,'true','2025-04-16 11:17:24','2025-04-16 11:17:24'),(6,'currency','decimal_mark',0,'\".\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(7,'currency','thousands_separator',0,'\",\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(8,'general','brand_name',0,'\"Sistema de Gestion Incidentes\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(9,'general','brand_logo',0,'\"sites/logo.jpg\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(10,'general','brand_logoHeight',0,'\"3rem\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(11,'general','site_active',0,'true','2025-04-16 11:17:24','2025-04-16 11:17:24'),(12,'general','site_favicon',0,'\"sites/favicon.ico\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(13,'mail','from_address',0,'\"corporativo2@masterelectronics.pe\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(14,'mail','from_name',0,'\"Master Electronics\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(15,'mail','driver',0,'\"smtp\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(16,'mail','host',0,'\"mail.masterelectronics.pe\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(17,'mail','port',0,'465','2025-04-16 11:17:24','2025-04-16 11:17:24'),(18,'mail','encryption',0,'\"tls\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(19,'mail','username',0,'\"eyJpdiI6Im12SGsxMWh1QkJHcVNPc2o5Q0NTZ3c9PSIsInZhbHVlIjoiS1UxM0RKdG00YUNlQm1SNkFPWTBaMWtUY0Q4RVByVHRLeHhMb1JUN08wNEt1dHpiS3YydFdHVUtQbVRxeFVLbSIsIm1hYyI6IjJiNzZiMTBhN2EyZjk1NmE2ZjM4N2U5ZTg2ZGM4Njg0OGU3MmRhMjYxMDAzMGVhOGUyZDY0NDc4ZTc1MzVjNzMiLCJ0YWciOiIifQ==\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(20,'mail','password',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(21,'mail','timeout',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(22,'mail','local_domain',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(23,'appearance','font',0,'\"inter\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(24,'appearance','table_sort_direction',0,'\"asc\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(25,'appearance','records_per_page',0,'10','2025-04-16 11:17:24','2025-04-16 11:17:24'),(26,'appearance','primary',0,'\"blue\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(27,'appearance','danger',0,'\"red\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(28,'appearance','gray',0,'\"gray\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(29,'appearance','info',0,'\"indigo\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(30,'appearance','success',0,'\"green\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(31,'appearance','warning',0,'\"amber\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(32,'localization','date_format',0,'\"M j, Y\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(33,'localization','time_format',0,'\"g:i A\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(34,'localization','week_start',0,'1','2025-04-16 11:17:24','2025-04-16 11:17:24'),(35,'report','logo',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(36,'report','show_logo',0,'false','2025-04-16 11:17:24','2025-04-16 11:17:24'),(37,'report','header',0,'\"Reporte\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(38,'report','sub_header',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(39,'report','terms',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(40,'report','footer',0,'null','2025-04-16 11:17:24','2025-04-16 11:17:24'),(41,'report','accent_color',0,'\"#4F46E5\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(42,'report','font',0,'\"inter\"','2025-04-16 11:17:24','2025-04-16 11:17:24'),(43,'report','report_template',0,'\"default\"','2025-04-16 11:17:24','2025-04-16 11:17:24');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` bigint unsigned NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_employee_id_foreign` (`employee_id`),
  CONSTRAINT `users_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'superadmin','fany@superadmin.com','2025-03-30 18:29:54','$2y$12$o6PVDgmzHXma0PWUiP7LgeiC2aPwqXiMwf.Foo3Pv0QK2Xlpmw4RK',1,'OsSxxEmSPg','2025-03-30 18:29:54','2025-03-31 22:27:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

